<!-- Optional JavaScript --> 
<!-- jQuery first, then Popper.js, then Bootstrap JS --> 
<script src="js/jquery-3.4.1.min.js"></script> 
<script src="js/popper.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/slick.min.js"></script> 
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
<script src="js/floatingFormLabels.min.js"></script> 
<script src="js/script-Mob.js"></script> 
<script src="js/aos.js"></script> 
<script>
AOS.init({
	startEvent: 'load',
	duration: 700,
	offset:50,
});
</script>
