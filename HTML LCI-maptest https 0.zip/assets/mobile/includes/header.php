<header class="mainHeader">
    <nav class="navbar justify-content-between headNavWrap bgLine-1">
      <div class="insideHead-mng w-100 d-flex justify-content-between align-items-center">
        <div class="headLeft"></div>
        <a class="navbar-brand header-brand" href="index.php"> <img class="siteLogo w-100" src="images/logo-LCI.png" alt="Low Cost Insurance"> </a>
        <div class="headRght">
          <button type="button" class="btn btncall" data-toggle="modal" data-target="#slideCallInfo"> <img class="icon" src="images/icon-call.svg" alt=""> </button>
        </div>
      </div>
    </nav>
  </header>
  